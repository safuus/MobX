Prerequisites:

1. Ruby Environment Setup
-- Install RVM & setup environments: https://rvm.beginrescueend.com/
-- Install Ruby 1.9.2 using rvm

2. Install Goliath
-- Clone Goliath source: https://github.com/postrank-labs/goliath
-- Install Goliath gem from the source (gem install gives only a old version): cd goliath-source-directory; gem build goliath.gemspec ; gem install goliath-0.9.1.gem

3. Install Bundle
-- gem install bundler

SOURCE CODE INSTALL AND SETUP

1. git clone https://github.com/safuus/MobX.git
2. cd mobx/mobxserver
3. bundle install

