module MobX
  # The current version of MobX Server
  VERSION = '0.1'
end
