# User management classs
# 

class User
  attr: id
  
  def authenticate!
    User.new
  end
end
